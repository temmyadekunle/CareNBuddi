var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__12s2uxr._.js")
R.c("server/chunks/[root-of-the-server]__1sxvvx5._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_1-lsc8h.js")
R.m(15295)
module.exports=R.m(15295).exports
