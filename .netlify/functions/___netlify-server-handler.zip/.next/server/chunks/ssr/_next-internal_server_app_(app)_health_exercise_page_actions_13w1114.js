module.exports=[14120,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_health_exercise_page_actions_13w1114.js.map