module.exports=[70943,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_health-days_page_actions_069kelg.js.map