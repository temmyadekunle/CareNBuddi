module.exports=[72353,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_page_actions_00xswjq.js.map