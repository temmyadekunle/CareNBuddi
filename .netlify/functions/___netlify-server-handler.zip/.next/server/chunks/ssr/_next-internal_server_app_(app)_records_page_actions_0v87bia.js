module.exports=[95603,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_records_page_actions_0v87bia.js.map