module.exports=[78746,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_provider_register_page_actions_1xa9z4e.js.map