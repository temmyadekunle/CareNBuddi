module.exports=[56988,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_health_journey_page_actions_1tsm2rz.js.map