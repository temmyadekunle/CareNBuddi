module.exports=[26620,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_ask_page_actions_0ugatl0.js.map