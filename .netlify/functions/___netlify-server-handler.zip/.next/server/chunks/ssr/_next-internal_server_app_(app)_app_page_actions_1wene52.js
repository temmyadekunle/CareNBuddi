module.exports=[7251,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_app_page_actions_1wene52.js.map