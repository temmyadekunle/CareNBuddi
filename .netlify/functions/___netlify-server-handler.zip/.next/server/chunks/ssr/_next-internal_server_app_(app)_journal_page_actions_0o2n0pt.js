module.exports=[86446,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_journal_page_actions_0o2n0pt.js.map