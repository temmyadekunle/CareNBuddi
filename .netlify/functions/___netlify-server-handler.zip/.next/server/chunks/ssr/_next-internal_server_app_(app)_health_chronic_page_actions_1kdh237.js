module.exports=[17050,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_health_chronic_page_actions_1kdh237.js.map