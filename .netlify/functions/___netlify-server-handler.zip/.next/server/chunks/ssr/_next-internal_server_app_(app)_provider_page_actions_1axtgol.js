module.exports=[36679,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_provider_page_actions_1axtgol.js.map