module.exports=[69913,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_emergency_page_actions_1r-gtts.js.map