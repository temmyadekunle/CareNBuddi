module.exports=[90707,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_services_page_actions_1ok44a7.js.map