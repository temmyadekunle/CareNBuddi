globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/-AfwDJOMcZdIJDJMIqkn4/_buildManifest.js",
    "static/-AfwDJOMcZdIJDJMIqkn4/_ssgManifest.js",
    "static/-AfwDJOMcZdIJDJMIqkn4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/1rj7ns8rte9vc.js",
    "static/chunks/2u3-82q5iqm4d.js",
    "static/chunks/turbopack-3j3up6ab71i29.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
